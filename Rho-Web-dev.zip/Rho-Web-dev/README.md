# Rho-Web

node-project -: you have a need of run command to run node server localhost:8080
                "node server.js"
                
tradier-react/tradier -: you have a need of run command to run react code  localhost:3000
               "npm start"
               
