import React, { Component } from 'react';
import './loginCss.css';
import { TRADIER_APP_ID, loginApiUrl, isSendBox, defoultTestaccessCode, defoultTestAccount } from '../../../config';
// import {
//   BrowserRouter as Router,
//   Route,
//   Switch,
//   Link,
//   Redirect,
//   withRouter

// } from 'react-router-dom';
class Login extends Component {

  componentDidMount() {
    if (localStorage.getItem("Authorization")) {
      this.props.history.replace('/');
    }
    if (isSendBox) {
      console.log('sendbox section');
      localStorage.setItem('Authorization', defoultTestaccessCode);
      localStorage.setItem('ActiveAccountNumber', defoultTestAccount);
      this.props.history.replace('/');
    }
  }
  render() {


    return (
      <div className=" authentication-bg" style={{'background':'url(images/bg-pattern-light.svg)'}}>
        <div className="account-pages  ">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-lg-5">
                <div className="card mt-5">
                  

                  <div className="card-body p-4 ">
                  <a href="#">
                      <span><img src="images/rhoLogo.png" alt=""/></span>
                    </a>
                    <div className="text-center w-75 m-auto" style={{'padding-top':'30px'}}>
                      <h2 className="text-dark-50 text-center mt-0 font-weight-bold font-dark-by">Welcome to Rho</h2>
                      <p className="text-muted mb-4 text-muted-by">Powered by <b>jellifin</b>.</p>
                    </div>
                    <a className="btn btn-full b-white loginbutton" href={loginApiUrl + "oauth/authorize?client_id=" + TRADIER_APP_ID + "&scope=read,write,trade,market,stream &state=rhopost"}>Log In with Tradier Brokerage</a>
                    <div className="home-footer">
                      <p className="small-white text-muted-by">Brokerage Services provided by Tradier Brokerage , inc.</p>
                      <p className="small-white text-muted-by">Member FINRA & SIPC.</p>
                    </div>

                  </div>
                </div>


                <div className="row mt-3">
                  <div className="col-12 text-center">
                    <p className="text-muted text-muted-by">Don't have an account? <a href="https://brokerage.tradier.com/signup/getting-started?platform=69" target="blank" className="text-dark ml-1 text-muted-by"><b>Sign Up</b></a></p>
                  </div>
                </div>



              </div>

            </div>

          </div>
        </div>
        <footer class="footer footer-alt text-muted-by">
        2019 ©  Jellifin Financial, Inc - <a href="https://www.jellifin.com/" target="blank" className="text-muted-blue"><b>Jellifin.com</b></a>
        </footer>
      </div>
    );
  }
}

export default Login;
