import React, { Component } from 'react';
import { Link} from 'react-router-dom';
import './stocks.css';
import AccountToggle from '../../../element/account_toggle';
import StockFb from '../../../element/stocks/first_layout/stockFb';
import StockTrade from '../../../element/stocks/stockTrade';
import StockTqc from '../../../element/stocks/second_layout/stockTqc';



class Stocks extends Component {
    constructor(props) {   
        super(props);
        this.state={
            ActiveAccountNumber:'',
            Authorization:localStorage.getItem("Authorization"),
            userAccount:''
          } ;
          
        }
       
        
        
  render() {
   
    return (
        <div>
          <div className="container-fluid p-l-r-5 ">
          <AccountToggle ActiveAccountNumber={this.state.ActiveAccountNumber} backgroundClass="black-background" backgroundHeaderClass="black-background-header" navTextColorClass="nav-text-color" Cool="color" />
      </div>
              <div className="p-65">
           {/*  <h1>Welcome in stock {this.props.symbol} page . </h1>
               <Link to="/">Dashboard</Link> */}
               <StockFb/>
              {/* <StockTrade/> */}
              <StockTqc/>
            </div>
        </div>

    );
  } 
}

  export default Stocks;

