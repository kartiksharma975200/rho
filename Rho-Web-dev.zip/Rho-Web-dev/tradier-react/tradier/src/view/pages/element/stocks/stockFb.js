import React, { Component } from 'react';

import './stockFb.css'
class StockFb extends Component {

    constructor(props) {
        super(props);
    }


    render() {

        return (
            <div className="pad-5">
                <div className="card">
                    <div className="card-body">
                        <div className="table-responsive-sm">
                        <h4 className="header-title f-28">FB  <span className="f-13">Facebook Inc.</span></h4>
                        <h4 className="header-title f-28">$138.2445 <span className='f-24' >1.14 (2.24%)</span></h4>
                        <div className="graph">Graph place</div>

                        <ul className="option-stock-day-ul clearfix">
                                    <li><button className="btn btn-link-fb c-b-f-b underline ">1D</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b">5D</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b" >1M</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b">3M</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b">6M</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b">1Y</button></li>
                                    <li><button className="btn btn-link-fb c-b-f-b">2Y</button></li>
                                </ul>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}

export default StockFb;