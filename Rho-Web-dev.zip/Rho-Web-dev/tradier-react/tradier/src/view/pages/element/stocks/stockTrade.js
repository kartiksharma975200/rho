import React, { Component } from 'react';
import './stockTrade.css'

import StockCompany from './stockCompany';
class StockTrade extends Component {

    constructor(props) {
        super(props);
    }
    render() {

        return (
            <div className="container ">
                <div className="row">
                    <div className="col-xl-6 pad-5">

                        <div className="card">
                            <div className="card-body">
                                <h4 className="header-title f-20">TRADE</h4>

                                {/* nav start */}
                                
                                <ul className="nav nav-tabs nav-bordered-trade mb-2">
                                    <li className="nav-item-trade" >
                                        <a href="#home-b1" data-toggle="tab" aria-expanded="false" className="nav-link active">
                                            <i className="mdi mdi-call-missed d-lg-none d-block mr-1"></i>
                                            <span className="d-none d-lg-block">Stock</span>
                                        </a>
                                    </li>
                                    <li className="nav-item-trade">
                                        <a href="#profile-b1" data-toggle="tab" aria-expanded="true" className="nav-link">
                                            <i className="mdi mdi-basket d-lg-none d-block mr-1"></i>
                                            <span className="d-none d-lg-block">Option</span>
                                        </a>
                                    </li>
                                    <li className="nav-item-trade">
                                        <a href="#profile-b1" data-toggle="tab" aria-expanded="true" className="nav-link">
                                            <i className="mdi mdi-basket d-lg-none d-block mr-1"></i>
                                            <span className="d-none d-lg-block">Spread</span>
                                        </a>
                                    </li>
                                    <li className="nav-item-trade">
                                        <a href="#profile-b1" data-toggle="tab" aria-expanded="true" className="nav-link">
                                            <i className="mdi mdi-basket d-lg-none d-block mr-1"></i>
                                            <span className="d-none d-lg-block">Combo</span>
                                        </a>
                                    </li>

                                </ul>
                                {/* nav End */}

                                {/* bid start */}
                                <div className="row top-margin">
                                    <div className="col-lg-6 col-sm-6 col-xs-12">
                                        <table className="table table-sm table-centered last-right mb-0">
                                            <tbody>
                                                <tr>
                                                    <td>Bid</td>
                                                    <td>137.10 x 25</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div className="col-lg-6 col-sm-6 col-xs-12">
                                        <table className="table table-sm table-centered last-right mb-0">
                                            <tbody>
                                                <tr>
                                                    <td>Ask</td>
                                                    <td>137.10 x 10</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                {/* bid end */}

                                {/* button start */}
                                <div className="row positionbuttongroup btn-margin top-margin">
                                    <div className="buysellLiset-trade ">
                                        <button type="button" className="btn btn-warning" >Buy</button>
                                        <button type="button" className="btn btn-outline-warning">Sell</button>
                                    </div>
                                    <div className="opencloseList">
                                        <button type="button" className="btn btn-warning" >Open</button>
                                        <button type="button" className="btn btn-outline-warning" >Close</button>
                                    </div>
                                </div>

                                {/* button end */}

                                {/* shares start */}
                                <div className="row top-margin">
                                    <div className="col-lg-6 col-sm-6 col-xs-12">
                                        <table className="table table-sm table-centered last-right mb-0">
                                            <tbody>
                                                <tr>
                                                    <td>Shares</td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div className="col-lg-6 col-sm-6 col-xs-12">
                                        <table className="table table-sm table-centered last-right mb-0">
                                            <tbody>
                                                <tr>
                                                    <td> <input type="number" className="form-control t-a-r" placeholder="0" /></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                {/* shares end */}



                            </div>
                            {/* order type start */}
                            <div className="top-margin order-option"  >
                                <select className="form-control t-a-r">
                                    <option value="">Order Type</option>}
                                </select>
                            </div>

                            {/* order type end */}

                            {/* Stop price start */}

                            <div className="row  top-margin left-margin" >
                                <div className="col-lg-6 col-sm-6 col-xs-12">
                                    <table className="table table-sm table-centered last-right mb-0">
                                        <tbody>
                                            <tr>
                                                <td>Stop Price</td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div className="col-lg-6 col-sm-6 col-xs-12">
                                    <table className="table table-sm table-centered last-right mb-0">
                                        <tbody>
                                            <tr>
                                                <td> <input type="number" className="form-control t-a-r" placeholder="0" /></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            {/* Stop price End */}

                            {/* Limit price start */}

                            <div className="row left-margin">
                                <div className="col-lg-6 col-sm-6 col-xs-12">
                                    <table className="table table-sm table-centered last-right mb-0">
                                        <tbody>
                                            <tr>
                                                <td>Limit Price</td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div className="col-lg-6 col-sm-6 col-xs-12">
                                    <table className="table table-sm table-centered last-right mb-0">
                                        <tbody>
                                            <tr>
                                                <td> <input type="number" className="form-control t-a-r" placeholder="0" /></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            {/* Limit price End */}

                            {/* order type start */}
                            <div className="time-option">
                                <select className="form-control t-a-r">
                                    <option value="">Time In Force</option>}
                                </select>
                            </div>

                            {/* order type end */}


                            <div className="col-12 pad-0-16 btn-pre-left">
                                <button type="button" className="btn btn-pre btn-warning">Preview </button>
                            </div>
                            <div className="bottom-message">
                                <p >Brokerage Services provided by Tradier Brokerage, Inc. Member FINRA SIPC</p>

                            </div>
                        </div>

                    </div>
                    <div className="col-xl-6 pad-5 ">
                        <div className="card card-topCahrtAccount" >
                            <div className="card-body">
                                2
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-xl-6 pad-5">

                        <div className="card">
                            <div className="card-body">
                            <StockCompany/>
                            </div>
                            </div>
                            </div>
                            </div>
            </div>
        );
    }
}

export default StockTrade;