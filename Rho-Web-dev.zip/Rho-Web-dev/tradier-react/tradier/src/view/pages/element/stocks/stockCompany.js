import React, { Component } from 'react';
import './stockCompany.css';
class StockCompany extends Component{

    constructor(props) {
        super(props);
    }

    render() {
        return (
       <div>jai ram ji ki</div>
        );
    }
}

export default StockCompany;