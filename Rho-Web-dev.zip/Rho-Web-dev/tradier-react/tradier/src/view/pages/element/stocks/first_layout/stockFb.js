import React, { Component } from 'react';
import './stockFb.css';
class StockFb extends Component {

    constructor(props) {
        super(props);
        this.state = {
            getDataActiveBtn: 1,
        }
    }

    getGraphData(btnActiveStatus) {
        this.setState({ getDataActiveBtn: btnActiveStatus });
    }
    render() {

        return (
            <div className="pad-5">
                <div className="card black-background card-border">
                    <div className="card-body">

                        <div className="row">
                            <div className="col-lg-6 col-sm-6 col-xs-12">
                                <div style={{ float: "left" }}><h4 className="header-title f-28 header-title-left text-color">FB <span className="f-13">Facebook Inc.</span></h4></div>
                            </div>
                            <div className="col-lg-6 col-sm-6 col-xs-12">
                                <div style={{ float: "right" }}><button type="button" className="btn btn-warning btn-follow header-title-right">Follow</button></div>
                            </div>
                        </div>
                        <div className="table-responsive-sm">
                            <h4 className="header-title f-28 title-color">$138.2445 <span className='f-24' >1.14 (2.24%)</span></h4>
                            <div className="graph">Graph place</div>

                            <ul className="option-stock-day-ul clearfix">
                                <li><button className={this.state.getDataActiveBtn === 1 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(1)}>1D</button></li>
                                <li><button className={this.state.getDataActiveBtn === 2 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(2)}>5D</button></li>
                                <li><button className={this.state.getDataActiveBtn === 3 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(3)}>1M</button></li>
                                <li><button className={this.state.getDataActiveBtn === 4 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(4)}>3M</button></li>
                                <li><button className={this.state.getDataActiveBtn === 5 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(5)}>6M</button></li>
                                <li><button className={this.state.getDataActiveBtn === 6 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(6)}>1Y</button></li>
                                <li><button className={this.state.getDataActiveBtn === 7 ? "btn btn-link-fb c-b-f-b title-color underline" : "btn btn-link-fb c-b-f-b title-color"} onClick={() => this.getGraphData(7)}>2Y</button></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}

export default StockFb;