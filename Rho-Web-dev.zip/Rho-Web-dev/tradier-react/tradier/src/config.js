export var apiUrl="http://localhost:8080/";
export var baseUrl="http://localhost:3000/";
export var callbackURL: "http://localhost:3000/auth/tradier/callback";
export var TRADIER_APP_ID = "VVxxXZxu8y7asJzxB4LGHDO2zet0fjjG";
export var TRADIER_APP_SECRET = "GQUHe7Cg7eGAfVDc";
export var loginApiUrl="https://api.tradier.com/v1/";
export var refreshTimeInterval=3000;
export var isSendBox=true;
export var defoultTestAccount="VA22459606";
export var sendBoxurl="https://sandbox.tradier.com/v1/";
export var defoultTestaccessCode ="9hdR5iv3N4asyPqVkMVylSfxYuir";



//paggination 
export var cellViewOnPaggination=20;
